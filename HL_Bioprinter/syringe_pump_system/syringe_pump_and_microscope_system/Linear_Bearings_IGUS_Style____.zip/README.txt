                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:24990
Linear Bearings, IGUS Style !!! by PropsFactory is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

*February 2018*
*I am still using these on my main 3D printer, and they have almost 5 years!*

--
Updated the LM8UU V3 (last file in the list) to simpler version.  

These Linear bearings are good replacement parts for those who get bored with "NOISY" LMxUU ... I Know somehow some "Cheap Bearings" can do this ...  

But !!! Instead of changing all the carriage ... switching to PLA "old style bearings", I designed "ready to print" Bearings, There is Three equivalents, LM6UU, LM8UU & LM10UU !.  

They are all the same size as original bearings :)  

Tooth thickness is made to print well on 0.5mm nozzle, altought a LM10UU 0.35mm will print really nice :)  

More tooth is better :)

# Instructions

Hum :) well

First thing ... simple insert the printed bearings in your rods, and "play with them" rolling/sliding, to ensure they slide well, you can also lubricant them !! the lubricant will stay between tooths !!!

<b>Simply print slow with 0 infill and 3 perimeters at least.</b>

Hum and ... that's all I think :)

<b>Tested them on my X & Y at 120mm/s infill and 200mm/s travel they do not fail :) </b>

<b>Added: LM12UU Version</b>